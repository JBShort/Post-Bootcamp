import React, {useState} from 'react';
import axios from 'axios';
import { navigate, Link } from '@reach/router';

const AuthorForm = () => {
    const [name, setName] = useState("");
    const [dbErrors, setDbErrors] = useState([]);

    const createAuthor = e => {
        e.preventDefault();
        const newAuthor = {
            name,
        }

        axios.post('http://localhost:8000/api/authors/new', newAuthor)
            .then(res => {
                console.log(res);
                navigate("/")
            })
            .catch(err => {
                console.log("Error Triggered OwO please look at the reason!!!!");
                console.log(err.response.data)
                const {errors} = err.response.data;
                const messages = Object.keys(errors).map(error => errors[error].message);
                setDbErrors(messages);
            })
    }

    return (
        <div>
            <h3>Add a New Author</h3>
            <form onSubmit={createAuthor}>
            {dbErrors.map((err, i) => <p key={i}>{err}</p>)}
                <label>Full Author Name: </label>
                <input type="text" onChange={(e) => setName(e.target.value)} placeholder="Enter First and Last Name here" value={name}/>
                <div>
                    <input type="submit" value="Create" />
                    <button> <Link to="/">Cancel</Link> </button>
                </div>
            </form>
        </div>
    )
}

export default AuthorForm
