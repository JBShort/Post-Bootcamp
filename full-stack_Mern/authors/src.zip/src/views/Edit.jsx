import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { Link, navigate } from "@reach/router"

const Edit = (props) => {
    const {id} = props;
    const [author, setAuthor] = useState({})
    const [name, setName] = useState('');
    const [dbErrors, setDbErrors] = useState([]);

    const getAuthorFromDB = (id) => {
        console.log(id);
        axios.get('http://localhost:8000/api/authors/' + id)
            .then(res => {
                console.log(res.data);
                setAuthor(res.data);
            })
            .catch(err => console.log(err))
    }

    useEffect(() => {
        getAuthorFromDB(id);
    }, [])

    const updateAuthor = e => {
        e.preventDefault();
        axios.put('http://localhost:8000/api/authors/update/' + id, {
            name,
        })
            .then(res => {
                console.log(res)
                navigate("/")
            })
            .catch(err => {
                console.log("Error Triggered OwO please look at the reason!!!!");
                console.log(err.response.data)
                const {errors} = err.response.data;
                const messages = Object.keys(errors).map(error => errors[error].message);
                setDbErrors(messages);
            })


    }
    return (
        <div>
            {dbErrors.map((err, i) => <p key={i}>{err}</p>)}
            <form onSubmit={updateAuthor}>
                <label>Full Author Name: </label>
                <input type="text" onChange={(e) => setName(e.target.value)} placeholder={author.name} value={name}/>
                <div>
                    <input type="submit" value="Update" />
                    <button> <Link to="/">Cancel</Link> </button>
                </div>
            </form>
        </div>
    )
}

export default Edit;
