import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { Link } from "@reach/router"

const Main = (props) => {
    const [authors, setAuthors] = useState([]);

    useEffect(() => {
        getAuthorsFromDB()
    }, [])

    const getAuthorsFromDB = () => {
        axios.get('http://localhost:8000/api/authors')
            .then(res => {
                console.log(res.data);
                setAuthors(res.data);
            })
            .catch(err => console.log(err))
    }

    const deleteAuthors = (id) => {
        console.log(id);
        axios.delete('http://localhost:8000/api/authors/delete/' + id)
            .then(res => {
                console.log(res.data);
                setAuthors(authors.filter(author => author._id !== id))
            })
            .catch(err => console.log(err))
    }

    return (
        <div>
            <Link to="/authors/create">Add a new author</Link>
            <p>We have quotes by: </p>
            <table>
                <tr>
                    <thead>Author</thead>
                    <thead>Actions Available</thead>
                </tr>
                {
                    authors.map((author, i) => {
                        return (
                            <tr>
                                <td>{author.name}</td>
                                <td>
                                    <button> <Link to={"/authors/edit/" + author._id}>Edit</Link> </button> |
                                    <button onClick={() => {deleteAuthors(author._id)}}>Delete</button>
                                </td>
                            </tr>
                        )
                    })
                }
            </table>
        </div>
    )
}

export default Main;