import './App.css';
import {Router} from '@reach/router';
import Main from './views/Main';
import Edit from './views/Edit';
import AuthorForm from './components/AuthorForm';

function App() {
  return (
    <div className="App">
      <h2>Favorite Authors</h2>
      <Router>
        <Main path="/"></Main>
        <AuthorForm path="/authors/create"></AuthorForm>
        <Edit path="/authors/edit/:id"></Edit>
      </Router>
    </div>
  );
}

export default App;
