import React from 'react';
import axios from 'axios';
import {Link} from '@reach/router'

const ProductList = (props) => {
    const {removeFromDom} = props;
    const deleteProduct = (id) => {
        axios.delete('http://localhost:8000/api/delete/' + id)
            .then(res => {
                removeFromDom(id)
            })
    }
    
    return (
        <div>
            {props.products.map((product, i) => {
                return <p key={i}>
                    {/* Link to is what we use instead of an A tag to link to the  */}
                    <Link to={"/products/" + product._id}>{product.title}</Link><br/>
                    <button onClick={(e) =>{deleteProduct(product._id)}}>Delete</button>
                </p>
            })}
        </div>
    )
}

export default ProductList;