import React, {useState} from 'react';
import axios from 'axios';

const ProductForm = (props) => {
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState(0);
    const [description, setDescription] = useState("");

    const submitHandler = e => {
        e.preventDefault();
        // make post request to create a new product
        axios.post('http://localhost:8000/api/new', {
            title,
            price,
            description
        })
            .then(res => {
                console.log(res);
                // it refreshes the whole page so this isn't good but also this is deprecated so this shouldn't be used going forward;
                window.location.reload(true);
            })
            .catch(err => console.log(err))
    }
    // onChange in the form will update (set) the title, price and description
    return (
        <form onSubmit={submitHandler}>
            <h2>New Product</h2>
            <p>
                <label>Title: </label>
                <input type="text" onChange={(e) => setTitle(e.target.value)} value={title}/>
            </p>
            <p>
                <label>Price: </label>
                <input type="number" onChange={(e)=> setPrice(e.target.value)} value={price} />
            </p>
            <p>
                <label>Description: </label>
                <input type="text" onChange={(e) => setDescription(e.target.value)} value={description} />
            </p>
            <input type="submit" value="Create" className="btn btn-primary" />
        </form>
    )
}

export default ProductForm;