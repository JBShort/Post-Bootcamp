import React, {useEffect, useState} from 'react';
import axios from 'axios';

const Update = (props) => {
    const {id} = props;
    const [title, setTitle] = useState('');
    const [price, setPrice] = useState('');
    const [description, setDescription] = useState('');

    useEffect(() => {
        axios.get('http://localhost:8000/api/updateProducts/' + id)
        .then(res => {
            setTitle(res.data.title);
            setPrice(res.data.price);
            setDescription(res.data.description);
        })
    }, [id])

    const updateProduct = e => {
        e.preventDefault();
        axios.put('http://localhost:8000/api/updateProducts/' + id,{
            title,
            price,
            description
        })
            .then(res => console.log(res));
    }

    return (
        <div>
            <h2>Update Product</h2>
            <form onSubmit={updateProduct}>
                <p>
                    <label className="form-label">Title: </label>
                    <input type="text" name="firstName" onChange={(e) => {setTitle(e.target.value)}} value={title}  />
                </p>
                <p>
                    <label className="form-label">Price:</label>
                    <input type="number" name="price" onChange={(e) => {setPrice(e.target.value)}} value={price}  />
                </p>
                <p>
                    <label className="form-label">Description</label>
                    <input type="text" name="description" onChange={(e) => {setDescription(e.target.value)}} value={description} />
                </p>
                <input type="submit" value="Update" />
            </form>
        </div>
    )
}

export default Update;