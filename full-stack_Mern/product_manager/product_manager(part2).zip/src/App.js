import React from 'react';
import ProductForm from './components/ProductForm.jsx'
import {Router} from '@reach/router';
import Main from './views/Main';
import Detail from './views/Detail';
import './App.css';

function App() {
  return (
    <div className="App">
      <Router>
        {/* Main is the list all products with the form on it */}
        <Main path="/products" />
        <Detail path='/products/:id'/>
      </Router>
    </div>
  );
}

export default App;
