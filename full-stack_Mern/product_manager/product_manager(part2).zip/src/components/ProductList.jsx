import React from 'react';
import axios from 'axios';
import {Link} from '@reach/router'

const ProductList = (props) => {
    return (
        <div>
            {props.products.map((product, i) => {
                return <p key={i}>
                    {/* Link to is what we use instead of an A tag to link to the  */}
                    <Link to={"/products/" + product._id}>{product.title}</Link><br/>
                </p>
            })}
        </div>
    )
}

export default ProductList;